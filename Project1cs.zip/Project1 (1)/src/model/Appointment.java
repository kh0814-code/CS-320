

package model;

import java.util.Date;

public class Appointment {
	private final String appointmentId;
	private Date appointmentDate;
	private String description;
	
	//constructor 
	public Appointment(String appointmentId, Date appointmentDate, String description) {
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment date cannot be null or in the past");	
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}
		
	//getters
	public String getAppointmentId() {
			return appointmentId;
	}
	public Date getAppointmentDate() {
			return appointmentDate;
	}
	public String getDescription() {
			return description;
	}
		
	//setters for updates 
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null || appointmentDate.before(new Date ())) {
			throw new IllegalArgumentException("Appointment date cannot be null or in the past");
		}
		this.appointmentDate = appointmentDate;
	}
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
}



