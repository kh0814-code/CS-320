package model;

public class Contact {
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		validateId(contactId);
		this.contactId = contactId;
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
		
	}
	
	//private validation methods
	private void validateId(String id) {
		if (id == null || id.length() >10) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
	}
	
	private void validateStringField(String value, int maxLength, String fieldName) {
		if (value == null || value.length() > maxLength) {
			throw new IllegalArgumentException("Invalid " + fieldName);
		}
	}
	
	private void validatePhone(String phone) {
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone must be exactly 10 digits");
		}
	}

	//getters
	public String getContactId() { 
		return contactId; 
	}
	public String getFirstName() {
		return firstName; 
	}
	public String getLastName() { 
		return lastName; 
	}
	public String getPhone() {
		return phone; 
	}
	public String getAddress() { 
		return address; 
	}
	
	//setters for the updatable fields
	public void setFirstName(String firstName) { 
		validateStringField(firstName, 10, "firstName"); 
		this.firstName = firstName; 
	}
	public void setLastName(String lastName) {
		validateStringField(lastName, 10, "lastName");
		this.lastName = lastName;
	}
	public void setPhone(String phone) {
		validatePhone(phone);
		this.phone = phone;
	}
	public void setAddress(String address) {
		validateStringField(address, 30, "address");
		this.address = address;
	}


}
