package model;

import java.util.HashMap;

import java.util.Map;

public class ContactService {
	private Map<String, Contact > contacts = new HashMap<>();
	
	//add a contact
	public void addContact(Contact contact) {
		if (contacts.putIfAbsent(contact.getContactId(), contact) != null) {
			throw new IllegalArgumentException("Contact ID must be unique");
		}
	}
	
	//delete a contact ID
	public void deleteContact(String contactId) {
		if (!contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contacts.remove(contactId);
	}
	
	//update fields 
	public void updateFirstName(String contactId, String firstName) {
		Contact contact = contacts.get(contactId);
		if (contact == null) throw new IllegalArgumentException("Contact ID not found");
		contact.setFirstName(firstName);
	}
	public void updateLastName(String contactId, String lastName) {
		Contact contact = contacts.get(contactId);
		if (contact == null) throw new IllegalArgumentException("Contact ID not found");
		contact.setLastName(lastName);	
	}
	public void updatePhone(String contactId, String phone) {
		Contact contact = contacts.get(contactId);
		if (contact == null) throw new IllegalArgumentException("Contact ID not found");
		contact.setPhone(phone);
	}
	public void updateAddress(String contactId, String address) {
		Contact contact = contacts.get(contactId);
		if (contact == null) throw new IllegalArgumentException("Contact ID not found");
		contact.setAddress(address);
	}
	
	//for testing 
	public Contact getContact(String contactId) {
		return contacts.get(contactId);
	}

}
