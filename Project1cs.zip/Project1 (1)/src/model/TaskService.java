package model;

import java.util.HashMap;

public class TaskService {
	private HashMap<String, Task> tasks;
	
	public TaskService() {
		tasks = new HashMap<>();
		
	}
	public boolean addTask(Task task) {
		if(tasks.containsKey(task.getTaskId())) return false;
		tasks.put(task.getTaskId(), task);
		return true;
	}
	public boolean deleteTask(String taskId) {
		return tasks.remove(taskId) != null;
	}
	public boolean updateName(String taskId, String newName) {
		Task task = tasks.get(taskId);
		if(task == null) return false;
		task.setName(newName);
		return true;
	}
	public boolean updateDescription(String taskId, String newDescription) {
		Task task = tasks.get(taskId);
		if(task == null) return false;
		task.setDescription(newDescription);
		return true;
	}
	public Task getTask(String taskId) {
		return tasks.get(taskId);
	}
}
