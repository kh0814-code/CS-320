/**
 * 
 */
/**
 * 
 */
module Project1 {
	requires org.junit.jupiter.api;
}