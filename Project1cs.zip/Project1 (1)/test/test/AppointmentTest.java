package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Appointment;
import model.AppointmentService;

import java.util.Date;
import java.util.Calendar;
 

public class AppointmentTest {
	
	private Date futureDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1); //for tomorrow 
		return cal.getTime();
	}
	
	@Test 
	void testValidAppointment() {
		Appointment appt = new Appointment("12345", futureDate(), "Checkup");
		assertEquals("12345", appt.getAppointmentId());
		assertEquals("Checkup", appt.getDescription());
	}
	
	@Test
	void testInvalidId() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, futureDate(), "Checkup");
		});
	}
	@Test
	void testPastDate() {
		Date pastDate = new Date(System.currentTimeMillis() - 100000);
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", pastDate, "Past appt");
		});
	}
	@Test
	void testInvalidDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", futureDate(), null);
		});
	}
	
	
}
