package test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import model.Contact;

class ContactTest {

		@Test
		void testContact() {
			Contact contact = new Contact("C1", "Kayla", "R", "1234567890", "123 main");
			assertEquals("C1", contact.getContactId());
			assertEquals("Kayla", contact.getFirstName());
			assertEquals("R", contact.getLastName());
			assertEquals("1234567890", contact.getPhone());
			assertEquals("123 main", contact.getAddress());
		}

		@Test
		void testGetContactId() {
			Contact contact = new Contact("C2", "John", "Doe", "0987654321", "321 main");
			assertEquals("C2", contact.getContactId());
		}

		@Test
		void testGetFirstName() {
			Contact contact = new Contact("C3", "Bob", "Smith", "1111111111", "213 main");
			assertEquals("Bob", contact.getFirstName());
		}

		@Test
		void testGetLastName() {
			Contact contact = new Contact("C4", "Chase", "H", "3333333333", "432 main");
			assertEquals("H", contact.getLastName());
		}

		@Test
		void testGetPhone() {
			fail("Not yet implemented");
		}

		@Test
		void testGetAddress() {
			fail("Not yet implemented");
		}

		@Test
		void testSetFirstName() {
			fail("Not yet implemented");
		}

		@Test
		void testSetLastName() {
			fail("Not yet implemented");
		}

		@Test
		void testSetPhone() {
			fail("Not yet implemented");
		}

		@Test
		void testSetAddress() {
			fail("Not yet implemented");
		}

	}
