
package com.yourname.test;

import com.yourname.contact.*;
import com.yourname.task.*;
import com.yourname.appointment.*;
import java.util.Calendar;
import java.util.Date;

public class MainTest {
    public static void main(String[] args) {
        System.out.println("=== Contact Tests ===");
        ContactService cs = new ContactService();
        Contact c = new Contact("C1","Kayla","Rose","1234567890","123 Main St");
        cs.addContact(c);
        System.out.println("Added contact: " + cs.getContact("C1").getFirstName());
        cs.updateFirstName("C1","Katie");
        System.out.println("Updated first name: " + cs.getContact("C1").getFirstName());
        cs.deleteContact("C1");
        System.out.println("Deleted contact C1");

        System.out.println("\n=== Task Tests ===");
        TaskService ts = new TaskService();
        Task t = new Task("T1","Do Homework","Complete math exercises");
        ts.addTask(t);
        System.out.println("Added task: " + ts.getTask("T1").getName());
        ts.updateName("T1","Do Science Homework");
        System.out.println("Updated task name: " + ts.getTask("T1").getName());
        ts.deleteTask("T1");
        System.out.println("Deleted task T1");

        System.out.println("\n=== Appointment Tests ===");
        AppointmentService aps = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date future = cal.getTime();
        Appointment a = new Appointment("A1", future, "Doctor Visit");
        aps.addAppointment(a);
        System.out.println("Added appointment: " + aps.getAppointment("A1").getDescription());
        aps.deleteAppointment("A1");
        System.out.println("Deleted appointment A1");
    }
}

