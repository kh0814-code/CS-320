package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import model.TaskService;

import model.Task;

class TaskServiceTest {

	private TaskService service;
	
	@BeforeEach
	void setUp() {
		service = new TaskService();
	}
	@Test
	void testAddTask() {
		Task task = new Task("1", "Test", "Desc");
		assertTrue(service.addTask(task));
		assertFalse(service.addTask(task));
	}
	@Test
	void testDeleteTask() {
		Task task = new Task("1", "Test", "Desc");
		service.addTask(task);
		assertTrue(service.deleteTask("1"));
		assertFalse(service.deleteTask("1"));
	}
	@Test
	void testUpdateTask() {
		Task task = new Task("1", "Test", "Desc");
		service.addTask(task);
		
		assertTrue(service.updateName("1",  "NewName"));
		assertEquals("NewName", service.getTask("1").getName());
		
		assertTrue(service.updateDescription("1", "NewDesc"));
		assertEquals("NewDesc", service.getTask("1").getDescription());
		
		assertFalse(service.updateName("2",  "Name"));
		assertFalse(service.updateDescription("2", "Desc"));
	}

}
