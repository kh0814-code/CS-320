package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Task;

class TaskttTest {

	@Test
	void testValidTaskCreation() {
		Task task = new Task("1", "TestTask", "This is a test task");
		assertEquals("1", task.getTaskId());
		assertEquals("TestTask", task.getName());
		assertEquals("This is a test task", task.getDescription());
		
	}
	@Test 
	void testInvalidTaskCreation() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Name", "Desc");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678901", "Name", "Desc");
		});
	}
	@Test
	void testInvalidNameAndDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", null, "Desc");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "Name", null);
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "Desc");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "Name", "This desccription is longer than 50 characters to test");
		});
	}
	@Test
	void testSetters() {
		Task task = new Task("1", "Name", "Desc");
		task.setName("NewName");
		task.setDescription("NewDesc");
		assertEquals("NewName", task.getName());
		assertEquals("NewDesc", task.getDescription());
	}
	@Test
	void testGetters() {
		Task task = new Task("2", "Read", "Read a book");
		assertEquals("2", task.getTaskId());
		assertEquals("Read", task.getName());
		assertEquals("Read a book", task.getDescription());
		
	}

}
